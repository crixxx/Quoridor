package es.urjc.mov.mcristin.quor.Jugador;

import android.content.Context;

import es.urjc.mov.mcristin.quor.Tablero.Casilla;
import es.urjc.mov.mcristin.quor.Tablero.Coordenadas;

import static es.urjc.mov.mcristin.quor.Juego.arrayParedes;
import static es.urjc.mov.mcristin.quor.Tablero.Tablero.COLUMNAS;
import static es.urjc.mov.mcristin.quor.Tablero.Tablero.FILAS;


public class JugadorHumano extends Jugador {
    public JugadorHumano() {
        super();
        tipoJugador tipo = tipoJugador.HUMANO;
    }

    private boolean esMovimientoValido(Coordenadas coordenadas) {
        boolean esValido = true;

        if(coordenadas.getX() >= FILAS || coordenadas.getY() >= COLUMNAS ||
                coordenadas.getX() < 0 || coordenadas.getY() < 0) {
            esValido = false;
        }else{
            //Busco si es pared
            for(int i = 0;i < arrayParedes.size(); i++){
                if(arrayParedes.get(i).getX() == coordenadas.getX()
                        && arrayParedes.get(i).getY() == coordenadas.getY()){
                    esValido = false;
                    break;
                }else{
                    continue;
                }
            }
        }

        return esValido;
    }

    public Casilla[][] MueveFicha(Context context, Coordenadas coordenadas, Casilla[][] tab) {

        if(esMovimientoValido(coordenadas)){
            Casilla miCasillaAnterior = null;
            for(int i = 0; i < FILAS; i++){
                for(int j = 0 ; j < COLUMNAS; j++){
                    Casilla c = tab[i][j];
                    if(c.equals(coordenadas)){
                        c.setEstadoCasilla(Casilla.Estado.MI_FICHA);
                    }else if(c.equals(miCasillaAnterior)){
                        c.setEstadoCasilla(Casilla.Estado.LIBRE);
                    }
                }

            }

            miCasillaAnterior = new Casilla(context,coordenadas, Casilla.Estado.LIBRE);
        }else{
            tab = null;
        }
        return tab;
    }


}
