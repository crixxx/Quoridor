package es.urjc.mov.mcristin.quor.Jugador;


public class JugadorRED extends Jugador {
    public JugadorRED() {
        super();
        tipoJugador tipo = tipoJugador.RED;

    }
}
