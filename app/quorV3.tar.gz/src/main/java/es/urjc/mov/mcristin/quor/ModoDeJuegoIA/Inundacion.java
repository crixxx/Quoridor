package es.urjc.mov.mcristin.quor.ModoDeJuegoIA;

/**
 * Created by crixx on 2/04/18.
 */

public class Inundacion extends ModoDeJuegoIA{

}
