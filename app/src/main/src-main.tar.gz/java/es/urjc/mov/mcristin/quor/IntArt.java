package es.urjc.mov.mcristin.quor;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static es.urjc.mov.mcristin.quor.InterfazUsuario.COLUMNAS;
import static es.urjc.mov.mcristin.quor.InterfazUsuario.FILAS;
import static es.urjc.mov.mcristin.quor.Juego.arrayParedes;

/**
 * Created by mcristin on 18/02/18.
 */

class IntArt {

    Juego juego = new Juego();

    List<Casilla> posiblesMovs = new ArrayList<Casilla>();
    Casilla anteriorCasillaIA;
    Casilla newCasilla;

    Coordenadas coorIA = new Coordenadas(0,0);

    public Casilla casillaOptima(List<Casilla> arrayPosiblesMovs, Context context){

        int i = 0;
        Casilla casillaOptima = arrayPosiblesMovs.get(i);
        int random = (int) (Math.random() * 100 +1);

        if(random >= 20){
            for(i = 0 ;i < arrayPosiblesMovs.size(); i++){
                if(arrayPosiblesMovs.get(i).getCoordenadas().getX() >= casillaOptima.getCoordenadas().getX()){
                    casillaOptima = arrayPosiblesMovs.get(i);
                }else{
                    continue;
                }
            }
        }else{
            casillaOptima = ponParedRndn(context);
        }

        return casillaOptima;
    }

    public Casilla[][] MueveFicha(Context context, Casilla[][] tab) {

        anteriorCasillaIA = new Casilla(context,coorIA, Casilla.Estado.LIBRE);
        posiblesMovs = juego.getPosiblesMovs(context, anteriorCasillaIA);
        boolean b = false; // Cuando sea posible movimiento si no, que vuelva a hacer click

        newCasilla = casillaOptima(posiblesMovs, context);

        if(newCasilla.getEstadoCasilla() == Casilla.Estado.PARED){
            for(int i = 0; i < FILAS; i++){
                for(int j = 0 ; j < COLUMNAS; j++){
                    if(tab[i][j].getCoordenadas().getX() == newCasilla.getCoordenadas().getX()
                            && tab[i][j].getCoordenadas().getY() == newCasilla.getCoordenadas().getY()){
                        tab[i][j].setEstadoCasilla(Casilla.Estado.PARED);
                        b = true;
                    }
                }

            }
        }else{
            if(newCasilla != null){
                for(int i = 0; i < FILAS; i++){
                    for(int j = 0 ; j < COLUMNAS; j++){
                        if(tab[i][j].getCoordenadas().getX() == newCasilla.getCoordenadas().getX()
                                && tab[i][j].getCoordenadas().getY() == newCasilla.getCoordenadas().getY()){
                            tab[i][j].setEstadoCasilla(Casilla.Estado.FICHA_IA);
                        }else if(tab[i][j].getCoordenadas().getX() == anteriorCasillaIA.getCoordenadas().getX()
                                && tab[i][j].getCoordenadas().getY() == anteriorCasillaIA.getCoordenadas().getY()){
                            tab[i][j].setEstadoCasilla(Casilla.Estado.LIBRE);
                        }
                    }

                }
                coorIA = new Coordenadas(newCasilla.getCoordenadas().getX(), newCasilla.getCoordenadas().getY());
            }else{
                tab = null;
            }
        }
        anteriorCasillaIA = newCasilla;

        return tab;
    }

    public Casilla ponParedRndn(Context context){
        Random r = new Random();
        int x;
        int y;
        r.nextInt(FILAS + 1);

        x = (int) (Math.random() * COLUMNAS);
        y = (int) (Math.random() * FILAS);

        Coordenadas coordenadas = new Coordenadas(x,y);
        Casilla pared = new Casilla(context,coordenadas, Casilla.Estado.PARED);
        arrayParedes.add(pared);

        return pared;

    }

    public Casilla[][] iniciaPartida(Context context, Casilla[][] tablero){
        for(int i = 0; i < FILAS; i++){
            for(int j = 0 ; j < COLUMNAS; j++){
                if(tablero[i][j].getCoordenadas().getX() == 0 && tablero[i][j].getCoordenadas().getY() == 0) {
                    tablero[i][j].setEstadoCasilla(Casilla.Estado.FICHA_IA);
                    anteriorCasillaIA = tablero[i][j];
                    newCasilla = anteriorCasillaIA;
                }else if(tablero[i][j].getEstadoCasilla() == Casilla.Estado.MI_FICHA){
                    tablero[i][j].setEstadoCasilla(Casilla.Estado.MI_FICHA);
                }else{
                    tablero[i][j].setEstadoCasilla(Casilla.Estado.LIBRE);
                }
            }

        }

        return tablero;

    }


}