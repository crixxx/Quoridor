package es.urjc.mov.mcristin.quor;

import android.content.Context;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import static es.urjc.mov.mcristin.quor.InterfazUsuario.COLUMNAS;
import static es.urjc.mov.mcristin.quor.InterfazUsuario.FILAS;

/**
 * Created by mcristin on 18/02/18.
 */

class Juego {

    private static final String TAG = "JUEGO --> ";
    static List<Casilla> arrayParedes = new ArrayList<Casilla>();
    Casilla casillaAnteriorIA;
    Casilla miCasillaAnterior;
    List<Casilla> posiblesMovs = new ArrayList<Casilla>();
    boolean ganador = false;

    public Casilla[][] IniciaPartida(InterfazUsuario context, Casilla[][] tab) {
        arrayParedes.clear();
        Coordenadas miFicha = new Coordenadas(FILAS-1,COLUMNAS-1);
        Coordenadas fichaIA = new Coordenadas(0,0);
        miCasillaAnterior = new Casilla(context, miFicha, Casilla.Estado.LIBRE);
        casillaAnteriorIA = new Casilla(context, fichaIA, Casilla.Estado.LIBRE);

        for(int i = 0; i < FILAS; i++){
            for(int j = 0 ; j < COLUMNAS; j++){
                if(tab[i][j].getCoordenadas().getX() == miCasillaAnterior.getCoordenadas().getX()
                        && tab[i][j].getCoordenadas().getY() == miCasillaAnterior.getCoordenadas().getY()){
                    tab[i][j].setEstadoCasilla(Casilla.Estado.MI_FICHA);
                    miCasillaAnterior = tab[i][j];

                }else if(tab[i][j].getCoordenadas().getX() == casillaAnteriorIA.getCoordenadas().getX()
                        && tab[i][j].getCoordenadas().getY() == casillaAnteriorIA.getCoordenadas().getY()){
                    tab[i][j].setEstadoCasilla(Casilla.Estado.FICHA_IA);
                    casillaAnteriorIA = tab[i][j];
                }else{
                    tab[i][j].setEstadoCasilla(Casilla.Estado.LIBRE);
                }
            }

        }

        return tab;

    }

    //Mueve ficha cuando es el usuario
    public Casilla[][] MueveFicha(Context context, Coordenadas coordenadas, Casilla[][] tab) {
        if(esMovimientoValido(coordenadas)){
            for(int i = 0; i < FILAS; i++){
                for(int j = 0 ; j < COLUMNAS; j++){
                    if(tab[i][j].getCoordenadas().getX() == coordenadas.getX()
                            && tab[i][j].getCoordenadas().getY() == coordenadas.getY()){
                        tab[i][j].setEstadoCasilla(Casilla.Estado.MI_FICHA);
                    }else if(tab[i][j].getCoordenadas().getX() == miCasillaAnterior.getCoordenadas().getX()
                            && tab[i][j].getCoordenadas().getY() == miCasillaAnterior.getCoordenadas().getY()){
                        tab[i][j].setEstadoCasilla(Casilla.Estado.LIBRE);
                    }
                }

            }

            miCasillaAnterior = new Casilla(context,coordenadas, Casilla.Estado.LIBRE);
        }else{
            tab = null;
        }

        return tab;
    }

    //Devuelve los posibles movimientos en forma de array de casillas
    public List<Casilla> getPosiblesMovs(Context context, Casilla casilla) {
        posiblesMovs.clear();
        Coordenadas arriba, abajo, izq, drch;
        Casilla cas1,cas2,cas3,cas4;

        int x = casilla.getCoordenadas().getX();
        int y = casilla.getCoordenadas().getY();

        //Calculo las coordenadas adyacentes
        arriba = new Coordenadas(x,y-1);
        abajo = new Coordenadas(x,y+1);
        drch = new Coordenadas(x+1,y);
        izq = new Coordenadas(x-1,y);

        List<Coordenadas> posiblesAux = new ArrayList<Coordenadas>();

        posiblesAux.add(arriba);
        posiblesAux.add(abajo);
        posiblesAux.add(drch);
        posiblesAux.add(izq);

        for(int i = 0; i < posiblesAux.size(); i++){
            if(esMovimientoValido(posiblesAux.get(i))
                    && casilla.getEstadoCasilla() != Casilla.Estado.PARED){
                Casilla cas = new Casilla(context,posiblesAux.get(i),Casilla.Estado.LIBRE);
                posiblesMovs.add(cas);
            }
        }

        for(int j = 0; j < posiblesMovs.size(); j++){
            for(int k = 0; k < arrayParedes.size();k++){
                if(posiblesMovs.get(j).getCoordenadas().getX() == arrayParedes.get(k).getCoordenadas().getX()
                        && posiblesMovs.get(j).getCoordenadas().getY() == arrayParedes.get(k).getCoordenadas().getY()){
                    posiblesMovs.remove(j);
                }
            }

        }

        return posiblesMovs;
    }

    private boolean esMovimientoValido(Coordenadas coordenadas) {
        boolean esValido = true;

        if(coordenadas.getX() >= FILAS || coordenadas.getY() >= COLUMNAS ||
                coordenadas.getX() < 0 || coordenadas.getY() < 0) {
            esValido = false;
        }else{
            //Busco si es pared
            for(int i = 0;i < arrayParedes.size(); i++){
                if(arrayParedes.get(i).getX() == coordenadas.getX()
                        && arrayParedes.get(i).getY() == coordenadas.getY()){
                    esValido = false;
                    break;
                }else{
                    continue;
                }
            }
        }

        return esValido;
    }

    public boolean haGanado(Coordenadas coordenadas) {

        if(coordenadas.getX() >= FILAS){
            ganador = true;
        }

        return ganador;
    }


    public Casilla[][] ponPared(Coordenadas coordenadas, Casilla[][] tab) {

        for(int i = 0; i < FILAS; i++){
            for(int j = 0 ; j < COLUMNAS; j++){
                if(tab[i][j].getCoordenadas().getX() == coordenadas.getX()
                        && tab[i][j].getCoordenadas().getY() == coordenadas.getY()){
                    tab[i][j].setEstadoCasilla(Casilla.Estado.PARED);
                    arrayParedes.add(tab[i][j]);
                }
            }

        }
        return tab;
    }

    public Casilla getCasilla(){
        return miCasillaAnterior;
    }
}